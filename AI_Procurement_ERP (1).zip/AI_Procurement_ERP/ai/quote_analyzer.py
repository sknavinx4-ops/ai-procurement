"""
ai/quote_analyzer.py

Lightweight extraction layer that turns a vendor's raw quotation text
(pasted or typed in) into structured fields: price, delivery days,
and warranty months. This lets a manager paste an email/quote as text
instead of manually filling every field, before the AI recommender scores it.

This uses regex-based pattern extraction rather than a full NLP model --
transparent, dependency-light, and good enough for typical quote formats
like "Price: Rs 45,000", "Delivery: 10 days", "Warranty: 1 year".
"""

import re


def extract_quote_fields(raw_text: str) -> dict:
    """
    Parse free-form quote text and pull out unit_price, delivery_days,
    and warranty_months. Returns None for any field it cannot confidently find.
    """
    text = raw_text.replace(",", "")

    result = {"unit_price": None, "delivery_days": None, "warranty_months": None}

    # Price: looks for currency symbols/words followed by a number.
    price_match = re.search(
        r"(?:price|cost|amount)[^\d₹rs.]*(?:₹|rs\.?|inr)?\s*([\d]+(?:\.\d+)?)",
        text,
        re.IGNORECASE,
    )
    if not price_match:
        price_match = re.search(r"(?:₹|rs\.?|inr)\s*([\d]+(?:\.\d+)?)", text, re.IGNORECASE)
    if price_match:
        result["unit_price"] = float(price_match.group(1))

    # Delivery: number followed by "day(s)" or "week(s)".
    delivery_match = re.search(r"([\d]+)\s*(day|days|week|weeks)", text, re.IGNORECASE)
    if delivery_match:
        value = int(delivery_match.group(1))
        unit = delivery_match.group(2).lower()
        result["delivery_days"] = value * 7 if "week" in unit else value

    # Warranty: number followed by "month(s)" or "year(s)".
    warranty_match = re.search(r"([\d]+)\s*(month|months|year|years)", text, re.IGNORECASE)
    if warranty_match:
        value = int(warranty_match.group(1))
        unit = warranty_match.group(2).lower()
        result["warranty_months"] = value * 12 if "year" in unit else value

    return result
