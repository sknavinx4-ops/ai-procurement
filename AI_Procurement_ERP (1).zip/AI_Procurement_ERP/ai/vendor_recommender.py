"""
ai/vendor_recommender.py

Weighted multi-criteria scoring engine for vendor recommendation.
This is the "AI" centerpiece: given a set of quotes for one RFQ, it scores
each vendor on Price, Rating, Delivery time and Warranty, then recommends
the best overall vendor -- not simply the cheapest one.

Uses sklearn's MinMaxScaler for normalization so the approach is genuinely
backed by a standard ML preprocessing technique, while staying transparent
and explainable (important for a procurement approval workflow).
"""

from sklearn.preprocessing import MinMaxScaler
import numpy as np

# Default weights -- must sum to 1.0. These match the plan:
# Price 40%, Rating 25%, Delivery 20%, Warranty 15%.
DEFAULT_WEIGHTS = {
    "price": 0.40,
    "rating": 0.25,
    "delivery": 0.20,
    "warranty": 0.15,
}


def score_quotes(quotes, weights=None):
    """
    Score a list of quote dicts and return them annotated with ai_score,
    sorted best-first.

    Each quote dict must contain:
        vendor_id, vendor_name, unit_price, delivery_days, rating, warranty_months

    Lower price and lower delivery days are better (cost/speed).
    Higher rating and higher warranty are better (quality/coverage).
    """
    if not quotes:
        return []

    weights = weights or DEFAULT_WEIGHTS

    prices = np.array([[q["unit_price"]] for q in quotes], dtype=float)
    deliveries = np.array([[q["delivery_days"]] for q in quotes], dtype=float)
    ratings = np.array([[q["rating"]] for q in quotes], dtype=float)
    warranties = np.array([[q["warranty_months"]] for q in quotes], dtype=float)

    scaler = MinMaxScaler()

    # For price and delivery, LOWER is better, so we invert the normalized score.
    if len(quotes) == 1:
        # MinMaxScaler needs variance; with a single quote everything is "best".
        price_score = np.array([[1.0]])
        delivery_score = np.array([[1.0]])
        rating_score = np.array([[1.0]])
        warranty_score = np.array([[1.0]])
    else:
        price_score = 1 - scaler.fit_transform(prices)
        delivery_score = 1 - scaler.fit_transform(deliveries)
        rating_score = scaler.fit_transform(ratings)
        warranty_score = scaler.fit_transform(warranties)

    results = []
    for i, q in enumerate(quotes):
        composite = (
            price_score[i][0] * weights["price"]
            + rating_score[i][0] * weights["rating"]
            + delivery_score[i][0] * weights["delivery"]
            + warranty_score[i][0] * weights["warranty"]
        )
        ai_score = round(composite * 100, 1)

        reasons = []
        if price_score[i][0] == max(p[0] for p in price_score):
            reasons.append("Most competitive price")
        if rating_score[i][0] == max(r[0] for r in rating_score):
            reasons.append("Highest vendor rating")
        if delivery_score[i][0] == max(d[0] for d in delivery_score):
            reasons.append("Fastest delivery")
        if warranty_score[i][0] == max(w[0] for w in warranty_score):
            reasons.append("Best warranty coverage")
        if not reasons:
            reasons.append("Solid all-round balance of price, rating, delivery and warranty")

        results.append(
            {
                **q,
                "ai_score": ai_score,
                "reasons": reasons,
            }
        )

    results.sort(key=lambda r: r["ai_score"], reverse=True)
    return results


def recommend_vendor(quotes, weights=None):
    """Convenience wrapper: returns the single top-scoring quote, or None."""
    scored = score_quotes(quotes, weights)
    return scored[0] if scored else None
