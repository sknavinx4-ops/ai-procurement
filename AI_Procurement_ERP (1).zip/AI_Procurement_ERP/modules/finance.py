"""
modules/finance.py
Blueprint for tracking payments against purchase orders.
"""

from flask import Blueprint, render_template, request, redirect, url_for
from database import get_connection

finance_bp = Blueprint("finance", __name__)


@finance_bp.route("/finance")
def list_finance():
    conn = get_connection()
    records = conn.execute(
        """SELECT finance.*, purchase_orders.po_number, vendors.vendor_name
           FROM finance
           JOIN purchase_orders ON finance.po_id = purchase_orders.id
           JOIN vendors ON purchase_orders.vendor_id = vendors.id
           ORDER BY finance.id DESC"""
    ).fetchall()

    totals = conn.execute(
        """SELECT COALESCE(SUM(amount), 0) AS total,
                  COALESCE(SUM(paid_amount), 0) AS paid
           FROM finance"""
    ).fetchone()
    conn.close()

    pending = totals["total"] - totals["paid"]
    return render_template(
        "finance.html",
        records=records,
        total=totals["total"],
        paid=totals["paid"],
        pending=pending,
        active="finance",
    )


@finance_bp.route("/finance/pay/<int:finance_id>", methods=["POST"])
def record_payment(finance_id):
    amount = float(request.form.get("amount") or 0)
    conn = get_connection()
    record = conn.execute("SELECT * FROM finance WHERE id = ?", (finance_id,)).fetchone()

    if record:
        new_paid = record["paid_amount"] + amount
        status = "Paid" if new_paid >= record["amount"] else "Partially Paid"
        conn.execute(
            """UPDATE finance SET paid_amount = ?, payment_status = ?,
               updated_date = CURRENT_TIMESTAMP WHERE id = ?""",
            (new_paid, status, finance_id),
        )
        conn.commit()

    conn.close()
    return redirect(url_for("finance.list_finance"))
