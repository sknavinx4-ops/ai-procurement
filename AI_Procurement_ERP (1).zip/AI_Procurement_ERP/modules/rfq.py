"""
modules/rfq.py
Blueprint for RFQ (Request for Quotation) creation and listing.
"""

from flask import Blueprint, render_template, request, redirect, url_for
from database import get_connection
from datetime import datetime

rfq_bp = Blueprint("rfq", __name__)


def generate_rfq_number(conn):
    """Generate the next RFQ number like RFQ-2026-001."""
    year = datetime.now().year
    count = conn.execute("SELECT COUNT(*) AS c FROM rfqs").fetchone()["c"]
    return f"RFQ-{year}-{count + 1:03d}"


@rfq_bp.route("/rfq")
def list_rfqs():
    conn = get_connection()
    rfqs = conn.execute("SELECT * FROM rfqs ORDER BY id DESC").fetchall()
    conn.close()
    return render_template("rfq.html", rfqs=rfqs, active="rfq")


@rfq_bp.route("/rfq/add", methods=["POST"])
def add_rfq():
    data = request.form
    conn = get_connection()
    rfq_number = generate_rfq_number(conn)
    conn.execute(
        """INSERT INTO rfqs (rfq_number, product_name, quantity, required_date, status)
           VALUES (?, ?, ?, ?, ?)""",
        (
            rfq_number,
            data.get("product_name"),
            int(data.get("quantity") or 0),
            data.get("required_date"),
            "Open",
        ),
    )
    conn.commit()
    conn.close()
    return redirect(url_for("rfq.list_rfqs"))


@rfq_bp.route("/rfq/close/<int:rfq_id>", methods=["POST"])
def close_rfq(rfq_id):
    conn = get_connection()
    conn.execute("UPDATE rfqs SET status = 'Closed' WHERE id = ?", (rfq_id,))
    conn.commit()
    conn.close()
    return redirect(url_for("rfq.list_rfqs"))


@rfq_bp.route("/rfq/delete/<int:rfq_id>", methods=["POST"])
def delete_rfq(rfq_id):
    conn = get_connection()
    conn.execute("DELETE FROM rfqs WHERE id = ?", (rfq_id,))
    conn.commit()
    conn.close()
    return redirect(url_for("rfq.list_rfqs"))
