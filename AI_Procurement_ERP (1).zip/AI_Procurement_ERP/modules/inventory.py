"""
modules/inventory.py
Blueprint for viewing and manually adjusting inventory.
"""

from flask import Blueprint, render_template, request, redirect, url_for
from database import get_connection

inventory_bp = Blueprint("inventory", __name__)


@inventory_bp.route("/inventory")
def list_inventory():
    conn = get_connection()
    items = conn.execute("SELECT * FROM inventory ORDER BY updated_date DESC").fetchall()
    conn.close()
    return render_template("inventory.html", items=items, active="inventory")


@inventory_bp.route("/inventory/adjust/<int:item_id>", methods=["POST"])
def adjust_inventory(item_id):
    """Manually adjust stock, e.g. after a stock count or damage write-off."""
    new_quantity = request.form.get("quantity")
    conn = get_connection()
    conn.execute(
        "UPDATE inventory SET quantity = ?, updated_date = CURRENT_TIMESTAMP WHERE id = ?",
        (int(new_quantity or 0), item_id),
    )
    conn.commit()
    conn.close()
    return redirect(url_for("inventory.list_inventory"))
