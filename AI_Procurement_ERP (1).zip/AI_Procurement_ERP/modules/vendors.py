"""
modules/vendors.py
Blueprint for the Vendor Management module: list, add, edit, delete vendors.
"""

from flask import Blueprint, render_template, request, redirect, url_for, jsonify
from database import get_connection

vendors_bp = Blueprint("vendors", __name__)


@vendors_bp.route("/vendors")
def list_vendors():
    conn = get_connection()
    vendors = conn.execute("SELECT * FROM vendors ORDER BY id DESC").fetchall()
    conn.close()
    return render_template("vendors.html", vendors=vendors, active="vendors")


@vendors_bp.route("/vendors/add", methods=["POST"])
def add_vendor():
    data = request.form
    conn = get_connection()
    conn.execute(
        """INSERT INTO vendors (vendor_name, contact, email, category, rating, status)
           VALUES (?, ?, ?, ?, ?, ?)""",
        (
            data.get("vendor_name"),
            data.get("contact"),
            data.get("email"),
            data.get("category"),
            float(data.get("rating") or 0),
            data.get("status", "Active"),
        ),
    )
    conn.commit()
    conn.close()
    return redirect(url_for("vendors.list_vendors"))


@vendors_bp.route("/vendors/delete/<int:vendor_id>", methods=["POST"])
def delete_vendor(vendor_id):
    conn = get_connection()
    conn.execute("DELETE FROM vendors WHERE id = ?", (vendor_id,))
    conn.commit()
    conn.close()
    return redirect(url_for("vendors.list_vendors"))


@vendors_bp.route("/vendors/toggle_status/<int:vendor_id>", methods=["POST"])
def toggle_status(vendor_id):
    conn = get_connection()
    vendor = conn.execute("SELECT status FROM vendors WHERE id = ?", (vendor_id,)).fetchone()
    if vendor:
        new_status = "Inactive" if vendor["status"] == "Active" else "Active"
        conn.execute("UPDATE vendors SET status = ? WHERE id = ?", (new_status, vendor_id))
        conn.commit()
    conn.close()
    return redirect(url_for("vendors.list_vendors"))


@vendors_bp.route("/api/vendors")
def api_vendors():
    conn = get_connection()
    vendors = conn.execute("SELECT * FROM vendors ORDER BY id DESC").fetchall()
    conn.close()
    return jsonify([dict(v) for v in vendors])
