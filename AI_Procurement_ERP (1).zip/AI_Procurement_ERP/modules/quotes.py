"""
modules/quotes.py
Blueprint for quote submission and AI-powered vendor recommendation.

Flow:
1. For an open RFQ, add a quote per vendor (either fill fields directly,
   or paste raw quote text and let the AI extractor fill fields for you).
2. Once 2+ quotes exist for an RFQ, run the AI Vendor Recommendation,
   which scores every quote on Price / Rating / Delivery / Warranty
   and highlights the best overall vendor.
"""

from flask import Blueprint, render_template, request, redirect, url_for, flash
from database import get_connection
from ai.quote_analyzer import extract_quote_fields
from ai.vendor_recommender import score_quotes

quotes_bp = Blueprint("quotes", __name__)


@quotes_bp.route("/quotes/<int:rfq_id>")
def view_quotes(rfq_id):
    conn = get_connection()
    rfq = conn.execute("SELECT * FROM rfqs WHERE id = ?", (rfq_id,)).fetchone()
    vendors = conn.execute("SELECT * FROM vendors WHERE status = 'Active'").fetchall()

    raw_quotes = conn.execute(
        """SELECT quotes.*, vendors.vendor_name, vendors.rating
           FROM quotes
           JOIN vendors ON quotes.vendor_id = vendors.id
           WHERE quotes.rfq_id = ?""",
        (rfq_id,),
    ).fetchall()
    conn.close()

    quote_dicts = [dict(q) for q in raw_quotes]

    scored = []
    if len(quote_dicts) >= 1:
        scored = score_quotes(quote_dicts)

    return render_template(
        "quotes.html",
        rfq=rfq,
        vendors=vendors,
        scored=scored,
        active="quotes",
    )


@quotes_bp.route("/quotes/<int:rfq_id>/add", methods=["POST"])
def add_quote(rfq_id):
    data = request.form
    conn = get_connection()

    unit_price = data.get("unit_price")
    delivery_days = data.get("delivery_days")
    warranty_months = data.get("warranty_months")

    quantity_row = conn.execute("SELECT quantity FROM rfqs WHERE id = ?", (rfq_id,)).fetchone()
    quantity = quantity_row["quantity"] if quantity_row else 1
    total_price = float(unit_price or 0) * quantity

    conn.execute(
        """INSERT INTO quotes (rfq_id, vendor_id, unit_price, total_price, delivery_days, warranty_months)
           VALUES (?, ?, ?, ?, ?, ?)""",
        (
            rfq_id,
            int(data.get("vendor_id")),
            float(unit_price or 0),
            total_price,
            int(delivery_days or 0),
            int(warranty_months or 0),
        ),
    )
    conn.commit()
    conn.close()
    return redirect(url_for("quotes.view_quotes", rfq_id=rfq_id))


@quotes_bp.route("/quotes/<int:rfq_id>/extract", methods=["POST"])
def extract_quote(rfq_id):
    """
    AI-assisted entry: parse pasted quote text and pre-fill the add-quote
    form fields, returned back to the same page via query params.
    """
    raw_text = request.form.get("raw_text", "")
    vendor_id = request.form.get("vendor_id", "")
    fields = extract_quote_fields(raw_text)

    conn = get_connection()
    rfq = conn.execute("SELECT * FROM rfqs WHERE id = ?", (rfq_id,)).fetchone()
    vendors = conn.execute("SELECT * FROM vendors WHERE status = 'Active'").fetchall()
    raw_quotes = conn.execute(
        """SELECT quotes.*, vendors.vendor_name, vendors.rating
           FROM quotes JOIN vendors ON quotes.vendor_id = vendors.id
           WHERE quotes.rfq_id = ?""",
        (rfq_id,),
    ).fetchall()
    conn.close()

    quote_dicts = [dict(q) for q in raw_quotes]
    scored = score_quotes(quote_dicts) if quote_dicts else []

    return render_template(
        "quotes.html",
        rfq=rfq,
        vendors=vendors,
        scored=scored,
        active="quotes",
        prefill=fields,
        prefill_vendor_id=vendor_id,
    )
