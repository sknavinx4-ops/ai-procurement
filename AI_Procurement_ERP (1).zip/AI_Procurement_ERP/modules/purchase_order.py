"""
modules/purchase_order.py
Blueprint for generating and listing Purchase Orders, and for receiving
goods into inventory once a PO is marked received.
"""

from flask import Blueprint, render_template, request, redirect, url_for
from database import get_connection
from datetime import datetime

po_bp = Blueprint("po", __name__)


def generate_po_number(conn):
    year = datetime.now().year
    count = conn.execute("SELECT COUNT(*) AS c FROM purchase_orders").fetchone()["c"]
    return f"PO-{year}-{count + 1:03d}"


@po_bp.route("/purchase-orders")
def list_pos():
    conn = get_connection()
    pos = conn.execute(
        """SELECT purchase_orders.*, vendors.vendor_name, rfqs.product_name, rfqs.quantity
           FROM purchase_orders
           JOIN vendors ON purchase_orders.vendor_id = vendors.id
           JOIN rfqs ON purchase_orders.rfq_id = rfqs.id
           ORDER BY purchase_orders.id DESC"""
    ).fetchall()
    conn.close()
    return render_template("purchase_order.html", pos=pos, active="po")


@po_bp.route("/purchase-orders/create/<int:rfq_id>/<int:vendor_id>", methods=["POST"])
def create_po(rfq_id, vendor_id):
    conn = get_connection()
    rfq = conn.execute("SELECT * FROM rfqs WHERE id = ?", (rfq_id,)).fetchone()
    quote = conn.execute(
        "SELECT * FROM quotes WHERE rfq_id = ? AND vendor_id = ?", (rfq_id, vendor_id)
    ).fetchone()

    if rfq and quote:
        po_number = generate_po_number(conn)
        conn.execute(
            """INSERT INTO purchase_orders (po_number, vendor_id, rfq_id, total_amount, status)
               VALUES (?, ?, ?, ?, ?)""",
            (po_number, vendor_id, rfq_id, quote["total_price"], "Approved"),
        )
        po_id = conn.execute("SELECT last_insert_rowid() AS id").fetchone()["id"]

        # Create a matching pending finance record automatically.
        conn.execute(
            """INSERT INTO finance (po_id, amount, paid_amount, payment_status)
               VALUES (?, ?, 0, 'Pending')""",
            (po_id, quote["total_price"]),
        )

        conn.execute("UPDATE rfqs SET status = 'Closed' WHERE id = ?", (rfq_id,))
        conn.commit()

    conn.close()
    return redirect(url_for("po.list_pos"))


@po_bp.route("/purchase-orders/receive/<int:po_id>", methods=["POST"])
def receive_po(po_id):
    """Mark a PO as received and push the quantity into inventory."""
    conn = get_connection()
    po = conn.execute(
        """SELECT purchase_orders.*, rfqs.product_name, rfqs.quantity, vendors.vendor_name
           FROM purchase_orders
           JOIN rfqs ON purchase_orders.rfq_id = rfqs.id
           JOIN vendors ON purchase_orders.vendor_id = vendors.id
           WHERE purchase_orders.id = ?""",
        (po_id,),
    ).fetchone()

    if po:
        existing = conn.execute(
            "SELECT * FROM inventory WHERE product_name = ?", (po["product_name"],)
        ).fetchone()

        unit_price = po["total_amount"] / po["quantity"] if po["quantity"] else 0

        if existing:
            conn.execute(
                """UPDATE inventory SET quantity = quantity + ?, unit_price = ?,
                   supplier = ?, updated_date = CURRENT_TIMESTAMP WHERE id = ?""",
                (po["quantity"], unit_price, po["vendor_name"], existing["id"]),
            )
        else:
            conn.execute(
                """INSERT INTO inventory (product_name, quantity, unit_price, supplier)
                   VALUES (?, ?, ?, ?)""",
                (po["product_name"], po["quantity"], unit_price, po["vendor_name"]),
            )

        conn.execute(
            "UPDATE purchase_orders SET status = 'Received' WHERE id = ?", (po_id,)
        )
        conn.commit()

    conn.close()
    return redirect(url_for("po.list_pos"))
